/*
 * TestprogP0.java
 * Created on den 30 augusti 2005, 11:25
 */
import p0.*;
/**
 *
 * @author tsroax
 */
public class TestprogP0 {
    public static void main(String[] args) {
        DeckOfCards deck = new DeckOfCards();
        boolean control = DeckControl.deckControl(deck);
        if(control)
            extra.Output.meddelande("Kortleken �r ok!");
        else
            extra.Output.meddelande("Kortleken �r inte ok!");
        System.exit(0);
    }   
}
