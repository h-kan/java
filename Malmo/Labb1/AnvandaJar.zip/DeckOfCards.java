/*
 * DeckOfCards.java
 * Created on den 30 augusti 2005, 10:38
 */
package p0;

/**
 * <p>En instans av klassen representerar en kortlek</p>
 * @author Rolf Axelsson
 */
public class DeckOfCards {
    private int size;
    public static final int CLUBS=0, DIAMONDS=1, SPADES=2, HEARTS=3, VALUES=13;
    public static final int[] SUIT = {CLUBS,DIAMONDS,SPADES,HEARTS};
    private Card[] cards = new Card[VALUES*SUIT.length];
    
    public DeckOfCards() {
        for(int s=0; s<SUIT.length; s++) {
            for(int v=0; v<VALUES; v++)
                cards[s*13+v] = new Card(SUIT[s],v+1);
        }
        shuffle();
    }
    
    public void shuffle() {
        int rnd;
        Card tmp;
        for(int i=cards.length-1; i>0; i--) {
            rnd = (int)(Math.random()*i); // 0-50, 0-49, ...
            tmp = cards[i];
            cards[i] = cards[rnd];
            cards[rnd] = tmp;
        }
        size = 52;
    }
    
    public int size() {
        return size;
    }
    
    public Card nextCard() {
        size--;
        return cards[size];
    }
}
