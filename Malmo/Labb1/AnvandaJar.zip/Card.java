/*
 * Card.java
 * Created on den 30 augusti 2005, 10:36
 */
package p0;

/**
 * <p>En instans av klassen representerar ett kort i en kortlek. </p>
 * @author Rolf Axelsson
 */
public class Card {
    int suit;
    int value;
    
    /** Skapar en ny instans av ett kort 
     * @param suit Kortets f�rg
     * @param value Kortets val�r
     */
    public Card(int suit, int value) {
        this.suit = suit;
        this.value = value;
    }
    
    /**
     * Returnerar kortets f�rg
     * @return Kortets f�rg
     */
    public int getSuit() {
        return suit;
    }
    
    /**
     * Returnerar kortets val�r
     * @return Kortets val�r
     */
    public int getValue() {
        return value;
    }
}
