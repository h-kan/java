/*
 * DeckControl.java
 * Created on den 30 augusti 2005, 10:50
 */
package p0;

/**
 * <p>Beskrivning av klassen</p>
 * @author Rolf Axelsson
 */
public class DeckControl {
    public static boolean deckControl(DeckOfCards cards) {
        boolean[][] check = new boolean[DeckOfCards.SUIT.length][DeckOfCards.VALUES];  // All false
        boolean ok = true;
        Card card;
        
        cards.shuffle();
        while(cards.size()>0) {
            card = cards.nextCard();
            check[card.getSuit()][card.getValue()-1] = true;
        }
        
        for(int s=0; s<DeckOfCards.SUIT.length; s++)
            for(int v=0; v<DeckOfCards.VALUES; v++)
                ok = ok && check[s][v];
        return ok;
    }    
}
