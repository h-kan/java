package ovning.exempel;
import extra.*;

public class Bok {
  private String titel;
  private String isbn;

  public Bok() {
    this("","");
  }

  public Bok(String titel, String isbn) {
    this.titel = titel;
    this.isbn = isbn;
  }

  public String getTitel() {
    return titel;
  }

  public String getIsbn() {
    return isbn;
  }

  public void setTitel(String titel) {
    this.titel = titel;
  }

  public void setIsbn(String isbn) {
    this.isbn = isbn;
  }

  public String toString() {
    return titel+", ISBN: "+isbn;
  }
}
