package f2;

public class StartBMIEx {
  public static void main(String[] args) {
    BMI prog = new BMI();
    prog.bmiMethod();
//    prog.bmiMethod();
  }
}
