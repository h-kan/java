package f2;

public class StartNina {
  public static void main(String[] args) {
    Nina nina = new Nina();
    nina.presentation();
  }
}
