package f2;

public class StartAddSub {
  public static void main(String[] args) {
    AddSub as = new AddSub();
    as.addSub1();
//    as.addSub2();
  }
}
