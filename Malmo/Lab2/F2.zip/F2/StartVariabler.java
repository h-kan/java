package f2;

public class StartVariabler {
  public static void main(String[] args) {
    Variabler var = new Variabler();
    var.variabler();
  }
}
