package f2;

public class StartSparande {
  public static void main(String[] args) {
    Sparande prog = new Sparande();
    prog.spara();
    System.exit(0);
  }
}
