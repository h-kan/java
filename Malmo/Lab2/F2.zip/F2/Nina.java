package f2;

public class Nina {
  public void presentation() {
    System.out.println("Mitt namn �r Nina.");
    System.out.println();
    System.out.println("Jag �r 13 �r och v�ger 42 kilo.");
  }
}
