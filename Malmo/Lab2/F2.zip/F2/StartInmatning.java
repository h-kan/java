package f2;

public class StartInmatning {
  public static void main(String[] args) {
    Inmatning prog = new Inmatning();
    prog.inmatningExempel();
  }
}
