package f2;

public class StartWelcome1 {
  public static void main(String[] args) {
    Welcome1 w1 = new Welcome1();
    w1.printMessage();
  }
}
