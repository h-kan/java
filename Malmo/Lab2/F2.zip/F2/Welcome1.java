package f2;

public class Welcome1 {
  public void printMessage() {
    System.out.println("V�lkommen till ");
    System.out.println("Java-kurs vid");
    System.out.println("Malm� h�gskola!");
  }
}
