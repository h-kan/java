package laboration2;

public class StartaProgram2e {
    public static void main(String[] args) {
        Program2e prog = new Program2e();
        prog.resultat();
    }
}
