package laboration2;

public class StartaProgram2d {
    public static void main(String[] args) {
        Program2d prog = new Program2d();
        prog.stringTest();
    }
}
