package laboration2;
import javax.swing.*;

public class Program2d {
    public void stringTest() {
        String str1 = "f�delsedag", str2 = "gratulationer",
                str3 = "p�", str4 = "Hj�rtliga", str5 = "!";
        String res="";
        int alder = Integer.parseInt( JOptionPane.showInputDialog( "Ange din �lder" ) );
        // res = ...

        JOptionPane.showMessageDialog( null, res );
    }
}
